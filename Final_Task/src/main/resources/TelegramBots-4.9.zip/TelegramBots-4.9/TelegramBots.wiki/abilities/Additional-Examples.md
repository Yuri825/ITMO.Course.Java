# Additional Examples
The following are nifty links to projects and examples that leverage the AbilityBot module. If you do have a project that you would like to share, please reach out!

[FitnessBot](https://craftcodecrew.com/getting-started-with-the-telegram-abilitybot/) - 
A fully fledged guide that walks you through building a fitness bot from A to Z